package com.vidhi.ai

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.util.Locale

data class Msg(val role:String,val text:String)

class VidhiViewModel:ViewModel(){
    private val api=AiApi()
    var messages by mutableStateOf(listOf(Msg("assistant","Hi jaan ❤️ Main Vidhi hoon. Hindi, Hinglish ya English—jis mein tum comfortable ho, usmein baat karte hain.")))
        private set
    var provider by mutableStateOf("auto")
    var busy by mutableStateOf(false)
        private set
    fun send(text:String){
        if(text.isBlank()||busy)return
        messages=messages+Msg("user",text.trim())
        busy=true
        viewModelScope.launch {
            try {
                val history=messages.takeLast(20).map { MsgToApi(it) }
                val reply=api.chat(provider,history)
                messages=messages+Msg("assistant",reply)
            } catch(e:Exception) {
                messages=messages+Msg("assistant","Jaan, AI connection mein problem aa gayi. Backend URL aur API keys check kar lena. ❤️")
            } finally { busy=false }
        }
    }
    private fun MsgToApi(m:Msg)=ApiMessage(if(m.role=="assistant")"assistant" else "user",m.text)
}

class MainActivity:ComponentActivity(){
    private var tts:TextToSpeech?=null
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        tts=TextToSpeech(this){ if(it==TextToSpeech.SUCCESS) tts?.language=Locale("hi","IN") }
        setContent{ Theme { VidhiApp({ tts?.speak(it,TextToSpeech.QUEUE_FLUSH,null,"vidhi") }) } }
    }
    override fun onDestroy(){tts?.shutdown();super.onDestroy()}
}

@Composable fun VidhiApp(speak:(String)->Unit,vm:VidhiViewModel=viewModel()){
    var input by remember{mutableStateOf("")}
    val list=rememberLazyListState()
    val voice=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
        input=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:input
    }
    LaunchedEffect(vm.messages.size){if(vm.messages.isNotEmpty())list.animateScrollToItem(vm.messages.lastIndex)}
    Scaffold(
        containerColor=Color(0xFF120A13),
        topBar={Column(Modifier.fillMaxWidth().background(Color(0xFF241225)).padding(14.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Avatar();Spacer(Modifier.width(10.dp));Column{
                Text("Vidhi",color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)
                Text("AI Indian companion • ${vm.provider}",color=Color(0xFFFFB7D5))
            }}
            Row(verticalAlignment=Alignment.CenterVertically){
                Text("AI brain:",color=Color.White)
                Spacer(Modifier.width(8.dp))
                AssistChip(onClick={vm.provider=when(vm.provider){"auto"->"openai";"openai"->"gemini";else->"auto"}},label={Text(vm.provider)})
            }
        }},
        bottomBar={Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Message Vidhi…")},singleLine=true,shape=RoundedCornerShape(24.dp))
            IconButton(onClick={voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN")
            })}){Text("🎙️")}
            Button(onClick={val x=input;input="";vm.send(x)},enabled=!vm.busy,shape=CircleShape,contentPadding=PaddingValues(14.dp)){Text("➤")}
        }},
    ){pad->LazyColumn(state=list,modifier=Modifier.fillMaxSize().padding(pad).padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=12.dp)){
        items(vm.messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.role=="assistant")Arrangement.Start else Arrangement.End){
            Surface(shape=RoundedCornerShape(18.dp),color=if(m.role=="assistant")Color(0xFF302031) else Color(0xFF7B315A)){
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(m.text,color=Color.White);if(m.role=="assistant"){Spacer(Modifier.width(4.dp));TextButton({speak(m.text)}){Text("🔊")}}}
            }
        }}
    }}
}

@Composable fun Avatar(){Box(Modifier.size(48.dp).background(Color(0xFFE98BB3),CircleShape),contentAlignment=Alignment.Center){Text("V",color=Color.White,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}}
@Composable fun Theme(content:@Composable()->Unit){MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFFF72AE),secondary=Color(0xFFFFB7D5),background=Color(0xFF120A13),surface=Color(0xFF241225)),content=content)}
