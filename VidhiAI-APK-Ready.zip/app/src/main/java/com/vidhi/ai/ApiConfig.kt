package com.vidhi.ai

object ApiConfig {
    // Change this to your deployed HTTPS backend URL.
    // Android emulator talking to a local computer can use http://10.0.2.2:3000
    const val BASE_URL = "https://YOUR-BACKEND.example.com"
}
