package com.vidhi.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class ApiMessage(val role: String, val content: String)

class AiApi {
    private val client=OkHttpClient()
    suspend fun chat(provider:String, history:List<ApiMessage>):String = withContext(Dispatchers.IO) {
        val arr=JSONArray()
        history.forEach {
            arr.put(JSONObject().put("role",it.role).put("content",it.content))
        }
        val body=JSONObject().put("provider",provider).put("messages",arr)
            .toString().toRequestBody("application/json".toMediaType())
        val req=Request.Builder().url(ApiConfig.BASE_URL.trimEnd('/')+"/chat")
            .post(body).build()
        client.newCall(req).execute().use { r ->
            val text=r.body?.string().orEmpty()
            if(!r.isSuccessful) throw Exception("Backend ${r.code}: $text")
            JSONObject(text).optString("reply","No reply received.")
        }
    }
}
