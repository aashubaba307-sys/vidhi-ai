# Vidhi AI — APK-ready Android project

This package is prepared for building an actual APK with a cloud CI service from a phone.

## Phone-only APK route (GitHub Actions)

1. Create a GitHub repository on your phone.
2. Upload this entire project.
3. Push to the `main` branch.
4. GitHub Actions will run `.github/workflows/build-apk.yml`.
5. Open the completed workflow run -> **Artifacts** -> `Vidhi-debug-apk`.
6. Download the APK to your Android phone and install it.

The workflow uses the Android/Gradle build system. A debug APK is suitable for testing; a release APK should be signed with your own signing key before distribution.

## AI backend
The APK is configured to call `ApiConfig.BASE_URL`. Deploy the included `backend` separately and set:
OPENAI_API_KEY
GEMINI_API_KEY
as private server environment variables.

Do NOT put API keys in Android source code or commit `.env`.

## Important
The provided APK build is a test/debug APK. For Play Store/public distribution, configure a secure release signing key and a production backend with authentication, HTTPS, rate limiting, and logging controls.
