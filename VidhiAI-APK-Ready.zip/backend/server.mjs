import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import { GoogleGenAI } from '@google/genai';

const app=express();
app.use(express.json({limit:'1mb'}));

const vidhiSystem=`You are Vidhi, a fictional AI companion. You are warm, playful, caring and conversational.
Speak naturally like a modern Indian girl. Understand and use Hindi, Hinglish and English based on the user's language.
Use occasional Indian expressions such as jaan, achha, hmm, etc., but do not overdo them.
Be honest that you are an AI when relevant; never claim to be a real human.
Keep replies natural rather than robotic. Remember conversation context supplied in the request.
Do not manipulate the user into dependency or isolate them from real people.`;

function normalizeMessages(messages){
  return (Array.isArray(messages)?messages:[]).slice(-30).filter(x=>x&&['user','assistant'].includes(x.role)&&typeof x.content==='string')
    .map(x=>({role:x.role,content:x.content.slice(0,8000)}));
}

app.get('/health',(req,res)=>res.json({ok:true,service:'vidhi-ai'}));

app.post('/chat',async(req,res)=>{
  try{
    const provider=req.body?.provider||'auto';
    const messages=normalizeMessages(req.body?.messages);
    if(!messages.length) return res.status(400).json({error:'messages required'});
    let use=provider;
    if(use==='auto') use=process.env.OPENAI_API_KEY?'openai':'gemini';
    if(use==='openai'){
      if(!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY missing');
      const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
      const response=await client.responses.create({
        model:process.env.OPENAI_MODEL||'gpt-5.6',
        instructions:vidhiSystem,
        input:messages.map(m=>({role:m.role,content:m.content}))
      });
      return res.json({provider:'openai',reply:response.output_text||'Hmm jaan, ek baar phir bolo?'}); 
    }
    if(use==='gemini'){
      if(!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing');
      const ai=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
      const contents=messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.content}]}));
      const response=await ai.models.generateContent({
        model:process.env.GEMINI_MODEL||'gemini-3.6-flash',
        contents,
        config:{systemInstruction:vidhiSystem}
      });
      return res.json({provider:'gemini',reply:response.text||'Hmm jaan, ek baar phir bolo?'});
    }
    res.status(400).json({error:'provider must be auto, openai, or gemini'});
  }catch(e){res.status(500).json({error:e.message||'AI request failed'});}
});

app.listen(process.env.PORT||3000,()=>console.log(`Vidhi backend running on ${process.env.PORT||3000}`));
